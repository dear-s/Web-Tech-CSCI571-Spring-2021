// [START cloudrun_end_user_firebase_config]
// [START run_end_user_firebase_config]
const config = {
  apiKey: 'API_KEY',
  authDomain: 'PROJECT_ID.firebaseapp.com',
};
// [END run_end_user_firebase_config]
// [END cloudrun_end_user_firebase_config]
