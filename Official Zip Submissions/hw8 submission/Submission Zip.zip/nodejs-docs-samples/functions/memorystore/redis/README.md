<img src="https://avatars2.githubusercontent.com/u/2810941?v=3&s=96" alt="Google Cloud Platform logo" title="Google Cloud Platform" align="right" height="96" width="96"/>

# Google Cloud Functions - Cloud Memorystore sample

See:

* [Cloud Functions Cloud Memorystore sample source code][code]

[code]: index.js
